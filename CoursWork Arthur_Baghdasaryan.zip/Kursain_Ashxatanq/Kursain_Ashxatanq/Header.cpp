#include "Header.h"
#include <fstream>
#include <iostream>

void Graph::get_neighbors() 
{
	std::ifstream input("Graph.txt");
    input >> number_of_vertices;
    input >> number_of_edges;
    int tmp_1;
    int tmp_2;
    Neighbors.resize(number_of_vertices);
    for (int i = 0; i < number_of_edges; i++)
    {
        input >> tmp_1;
        input >> tmp_2;
        Neighbors[tmp_1].push_back(tmp_2);
        Neighbors[tmp_2].push_back(tmp_1);              
    }	
}

int Graph::get_Independent_Sets_number() 
{
    std::vector<int> temp;
    for (int i = 0; i < number_of_vertices; i++)
    {
        if (Neighbors[i].size() == 0) 
            temp.push_back(i); 
        else
        {
            if (Independent_Sets.empty())
                Independent_Sets.push_back(i);
            else
            {
                if (revice(i))
                    Independent_Sets.push_back(i);
            }
        }
    }
    while (!temp.empty()) {
        Independent_Sets.push_back(temp.back());
        temp.pop_back();
    }
    return Independent_Sets.size();
}


bool Graph::revice(int i) {
    bool tmp = true;
    for (int j = 0; j < Independent_Sets.size(); j++)
    {
        for (int k = 0; k < Neighbors[i].size(); k++)
        {
            if (Independent_Sets[j] == Neighbors[i][k])
                tmp = false;
        }
    }
    return tmp;
}

void Graph::print_Independent_Sets() {

    std::cout << "Maximum Independent Set size found is:  " << Independent_Sets.size() << std::endl;
    for (int i = 0; i < Independent_Sets.size(); i++)
    {
        std::cout << Independent_Sets[i] << "  ";
    }
    std::cout << std::endl;
}


