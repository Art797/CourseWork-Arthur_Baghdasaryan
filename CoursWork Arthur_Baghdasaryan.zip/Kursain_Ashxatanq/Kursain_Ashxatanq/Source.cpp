#include"Header.h"

int main() {
	Graph obj;
	obj.get_neighbors();
	obj.get_Independent_Sets_number();
	obj.print_Independent_Sets();
	return 0;
}