#pragma once
#include<vector>
class Graph
{
public:
	void get_neighbors();
	int get_Independent_Sets_number();
	void print_Independent_Sets();
private:
	std::vector<std::vector<int>> Neighbors;
	std::vector<int> Independent_Sets;
	int number_of_vertices, number_of_edges;
	bool revice(int);
};

